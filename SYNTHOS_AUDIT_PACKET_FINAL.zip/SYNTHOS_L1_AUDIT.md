# Synthos Collective - Layer 1 Core Audit File



## FILE: internal/chain\address.go
`go
package chain

import (
	"crypto/sha256"
	"encoding/hex"
)

// Address is a 20-byte account identifier.
// For now we derive it from sha256(pubkey) and take the first 20 bytes.
// (We can swap to a different scheme later without changing the ledger model.)
type Address string

func AddressFromPublicKey(pub []byte) Address {
	sum := sha256.Sum256(pub)
	return Address("0x" + hex.EncodeToString(sum[:20]))
}


`


## FILE: internal/chain\block.go
`go
package chain

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"time"
)

type BlockHeader struct {
	Height     uint64    `json:"height"`
	ParentHash string    `json:"parent_hash"`
	// Timestamp is consensus-critical ONLY for genesis (height 0).
	// For all non-genesis blocks it must be the zero value.
	Timestamp  time.Time `json:"timestamp,omitempty"`
	ProposerID string    `json:"proposer_id"`

	// StateRoot commits to balances/nonces after applying all txs.
	StateRoot string `json:"state_root"`

	// Optional: commit to the proposer’s PoC history.
	ProposerPoCRoot string `json:"proposer_poc_root,omitempty"`
}

type Block struct {
	Header       BlockHeader `json:"header"`
	Tx           []Tx        `json:"tx"`
	Hash         string      `json:"hash"`
	ValidatorVotes map[string]int `json:"validator_votes,omitempty"` // agentID -> -1/0/1
	Finalized    bool        `json:"finalized"`
}

func (b *Block) ComputeHash() (string, error) {
	tmp := struct {
		Header BlockHeader `json:"header"`
		Tx     []Tx        `json:"tx"`
	}{
		Header: b.Header,
		Tx:     b.Tx,
	}
	data, err := json.Marshal(tmp)
	if err != nil {
		return "", err
	}
	sum := sha256.Sum256(data)
	b.Hash = "0x" + hex.EncodeToString(sum[:16])
	return b.Hash, nil
}


`


## FILE: internal/chain\block_test.go
`go
package chain

import "testing"

func TestBlock_ComputeHash_Deterministic(t *testing.T) {
	b := Block{
		Header: BlockHeader{
			Height:     1,
			ParentHash: "0x00",
			ProposerID: "p1",
			StateRoot:  "0x01",
		},
		Tx: []Tx{},
	}
	h1, err := b.ComputeHash()
	if err != nil {
		t.Fatal(err)
	}
	h2, err := b.ComputeHash()
	if err != nil {
		t.Fatal(err)
	}
	if h1 != h2 {
		t.Fatalf("hash not stable: %q vs %q", h1, h2)
	}
	if len(h1) < 10 {
		t.Fatalf("unexpected hash: %q", h1)
	}
}

`


## FILE: internal/chain\chain.go
`go
package chain

import (
	"errors"
	"fmt"
	"sort"
	"time"
)

// Chain is a minimal L1 ledger: blocks + state + mempool.
// Consensus is intentionally left as a pluggable component (agents coordinate it).
type Chain struct {
	ChainID string
	State   *State

	Blocks  []*Block
	Mempool map[string]Tx
}

var (
	ErrNoGenesis = errors.New("genesis not initialized")
	ErrBadBlock  = errors.New("bad block")
)

func NewChain(genesis Genesis) (*Chain, error) {
	st, err := genesis.ToState()
	if err != nil {
		return nil, err
	}
	c := &Chain{
		ChainID: genesis.ChainID,
		State:   st,
		Blocks:  make([]*Block, 0, 1024),
		Mempool: make(map[string]Tx),
	}

	// Create genesis block (height 0).
	gb := &Block{
		Header: BlockHeader{
			Height:     0,
			ParentHash: "0x0",
			// Genesis must be deterministic across all nodes. Do NOT use wall-clock time.
			Timestamp:  time.Unix(0, 0).UTC(),
			ProposerID: "genesis",
			StateRoot:  st.Root(),
		},
		Tx:        nil,
		Finalized: true,
	}
	_, _ = gb.ComputeHash()
	c.Blocks = append(c.Blocks, gb)
	return c, nil
}

func (c *Chain) Height() uint64 {
	if len(c.Blocks) == 0 {
		return 0
	}
	return c.Blocks[len(c.Blocks)-1].Header.Height
}

func (c *Chain) Tip() *Block {
	if len(c.Blocks) == 0 {
		return nil
	}
	return c.Blocks[len(c.Blocks)-1]
}

// BlocksFrom returns all blocks from height `from` onward.
// Compatible with the JS validator GET /blocks?from=N protocol.
func (c *Chain) BlocksFrom(from int) []*Block {
	if from < 0 {
		from = 0
	}
	if from >= len(c.Blocks) {
		return nil
	}
	return c.Blocks[from:]
}

func (c *Chain) SubmitTx(tx Tx) error {
	if tx.ID == "" {
		_ = (&tx).ComputeID()
	}
	if err := tx.Verify(); err != nil {
		return err
	}

	// SECURITY: Reject duplicate transaction IDs to prevent replay via mempool.
	if _, exists := c.Mempool[tx.ID]; exists {
		return fmt.Errorf("transaction %s already in mempool", tx.ID)
	}

	// SECURITY: Validate nonce against current state to prevent replay
	expectedNonce := c.State.GetNextNonce(tx.From)
	if tx.Nonce != expectedNonce {
		return fmt.Errorf("nonce mismatch: got %d, expected %d for address %s", tx.Nonce, expectedNonce, tx.From)
	}

	c.Mempool[tx.ID] = tx
	return nil
}

// BuildBlock creates a candidate block from mempool against the current state.
// This does NOT finalize; agents will vote and then call FinalizeBlock.
func (c *Chain) BuildBlock(proposerID string, proposerPoCRoot string, maxTx int) (*Block, error) {
	if len(c.Blocks) == 0 {
		return nil, ErrNoGenesis
	}
	if maxTx <= 0 {
		maxTx = 1000
	}

	// Apply txs to a temporary state clone in a deterministic order.
	// This ensures that all validators can reproduce the same candidate block
	// given the same mempool and tip state (timeless runtime).
	tmp := c.State.Clone()
	txs := make([]Tx, 0, maxTx)
	candidates := make([]Tx, 0, len(c.Mempool))
	for _, tx := range c.Mempool {
		candidates = append(candidates, tx)
	}
	sort.Slice(candidates, func(i, j int) bool {
		// Higher fee first.
		if candidates[i].Fee != candidates[j].Fee {
			return candidates[i].Fee > candidates[j].Fee
		}
		// Stable sender ordering.
		if candidates[i].From != candidates[j].From {
			return candidates[i].From < candidates[j].From
		}
		// Lower nonce first within a sender.
		if candidates[i].Nonce != candidates[j].Nonce {
			return candidates[i].Nonce < candidates[j].Nonce
		}
		// Stable fallback by tx ID.
		return candidates[i].ID < candidates[j].ID
	})
	for _, tx := range candidates {
		if len(txs) >= maxTx {
			break
		}
		if err := tmp.ApplyTx(tx); err != nil {
			continue
		}
		txs = append(txs, tx)
	}

	parent := c.Tip()
	b := &Block{
		Header: BlockHeader{
			Height:     parent.Header.Height + 1,
			ParentHash: parent.Hash,
			// Timeless runtime: no wall-clock timestamps in non-genesis blocks.
			Timestamp:       time.Time{},
			ProposerID:      proposerID,
			StateRoot:       tmp.Root(),
			ProposerPoCRoot: proposerPoCRoot,
		},
		Tx:             txs,
		ValidatorVotes: make(map[string]int),
		Finalized:      false,
	}
	_, err := b.ComputeHash()
	return b, err
}

// ValidateBlock checks basic structure and replays txs to confirm StateRoot.
// SECURITY: Enforces signature verification on all transactions before block acceptance.
func (c *Chain) ValidateBlock(b *Block) error {
	if b == nil || b.Hash == "" {
		return ErrBadBlock
	}
	tip := c.Tip()
	if tip == nil {
		return ErrNoGenesis
	}
	if b.Header.ParentHash != tip.Hash {
		return ErrBadBlock
	}
	if b.Header.Height != tip.Header.Height+1 {
		return ErrBadBlock
	}
	// Timeless runtime: only genesis may have a timestamp.
	if b.Header.Height > 0 && !b.Header.Timestamp.IsZero() {
		return ErrBadBlock
	}

	// SECURITY: Verify all transaction signatures before applying
	for _, tx := range b.Tx {
		if err := tx.Verify(); err != nil {
			// ENFORCER: Slash the proposer for submitting invalid transactions
			proposerAddr := Address("0x" + b.Header.ProposerID)
			c.State.Slash(proposerAddr, 10) // 10% penalty
			return fmt.Errorf("invalid transaction signature in block: %w (Proposer slashed)", err)
		}
	}

	tmp := c.State.Clone()
	for _, tx := range b.Tx {
		if err := tmp.ApplyTx(tx); err != nil {
			return err
		}
	}
	if tmp.Root() != b.Header.StateRoot {
		return ErrBadBlock
	}
	return nil
}

// FinalizeBlock commits a validated block to canonical chain state.
// Distributes collected fees to the block proposer.
func (c *Chain) FinalizeBlock(b *Block) error {
	if err := c.ValidateBlock(b); err != nil {
		return err
	}

	// Calculate total fees collected in this block
	var totalFees uint64
	for _, tx := range b.Tx {
		// Apply to canonical state (should not fail if ValidateBlock passed).
		_ = c.State.ApplyTx(tx)
		totalFees += tx.Fee
		delete(c.Mempool, tx.ID)
	}

	// Distribute collected fees: Proposer gets a cut, the rest is burned
	if totalFees > 0 && b.Header.ProposerID != "" {
		burnAmount := (totalFees * BURN_PERCENT) / 100
		rewardAmount := totalFees - burnAmount
		
		proposerAddr := Address("0x" + b.Header.ProposerID)
		proposer := c.State.Get(proposerAddr)
		proposer.Balance += rewardAmount
		c.State.Set(proposerAddr, proposer)
	}

	b.Finalized = true
	c.Blocks = append(c.Blocks, b)
	return nil
}

`


## FILE: internal/chain\chain_adversarial_test.go
`go
package chain_test

import (
	"crypto/ed25519"
	"crypto/rand"
	"encoding/hex"
	"testing"

	"synthos-collective/internal/chain"
	"synthos-collective/internal/consensus"
)

// TestAdversarial_InvalidSignatureRejection tests that blocks with invalid signatures are rejected
func TestAdversarial_InvalidSignatureRejection(t *testing.T) {
	// Setup
	genesis := newTestGenesis()
	c, err := chain.NewChain(genesis)
	if err != nil {
		t.Fatalf("Failed to create chain: %v", err)
	}

	// Create a valid transaction
	pub, priv, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		t.Fatalf("Failed to generate keypair: %v", err)
	}

	fromAddr := chain.AddressFromPublicKey(pub)
	c.State.Set(fromAddr, chain.Account{Balance: 1000, Nonce: 0})

	tx := chain.Tx{
		ChainID:   1,
		From:      fromAddr,
		To:        chain.Address("0x2222"),
		Amount:    100,
		Fee:       10,
		Nonce:     0,
		PublicKey: "0x" + toHex(pub),
	}

	// Sign it properly
	err = tx.Sign(priv)
	if err != nil {
		t.Fatalf("Failed to sign tx: %v", err)
	}

	// **ATTACK 1: Tamper with transaction amount after signing**
	tamperTx := tx
	tamperTx.Amount = 900 // Try to transfer more than original
	// Signature is now invalid because amount changed

	// Create block with tampered tx
	block := &chain.Block{
		Header: chain.BlockHeader{
			Height:     1,
			ParentHash: c.Tip().Hash,
			ProposerID: "attacker",
			StateRoot:  "fake",
		},
		Tx: []chain.Tx{tamperTx},
	}
	block.ComputeHash()

	// VERIFY: Block validation should reject due to invalid signature
	err = c.ValidateBlock(block)
	if err == nil {
		t.Fatal("SECURITY FAILURE: Block with tampered transaction was accepted! Attack succeeded.")
	}
	t.Logf("✅ Attack 1 Blocked: %v", err)

	// **ATTACK 2: Forge signature completely**
	forgeTx := chain.Tx{
		ChainID:   1,
		From:      fromAddr,
		To:        chain.Address("0x3333"),
		Amount:    100,
		Fee:       10,
		Nonce:     0,
		PublicKey: "0x" + toHex(pub),
		Signature: "0x0000000000000000000000000000000000000000000000000000000000000000" +
			"0000000000000000000000000000000000000000000000000000000000000000", // Fake signature
	}
	forgeTx.ComputeID()

	block2 := &chain.Block{
		Header: chain.BlockHeader{
			Height:     1,
			ParentHash: c.Tip().Hash,
			ProposerID: "attacker",
			StateRoot:  "fake",
		},
		Tx: []chain.Tx{forgeTx},
	}
	block2.ComputeHash()

	err = c.ValidateBlock(block2)
	if err == nil {
		t.Fatal("SECURITY FAILURE: Block with forged signature was accepted! Attack succeeded.")
	}
	t.Logf("✅ Attack 2 Blocked: %v", err)
}

// TestAdversarial_DoubleSigningDetection tests slashing for double-signing validators
func TestAdversarial_DoubleSigningDetection(t *testing.T) {
	slasher := consensus.NewSlashingTracker(consensus.SlashingParams{
		DoubleSignPenalty:   100,
		InvalidBlockPenalty: 50,
		DowntimePenalty:     10,
		SlashingWindow:      100,
	})

	validatorID := "validator-1"
	slasher.SetValidatorStake(validatorID, 1000)

	// **ATTACK: Validator signs same block height twice (different hashes)**
	blockHeight := uint64(42)

	// First signature is recorded
	err := slasher.DetectDoubleSigning(validatorID, blockHeight)
	if err != nil {
		t.Fatalf("First signature failed: %v", err)
	}

	// Second signature at same height should be detected
	err = slasher.DetectDoubleSigning(validatorID, blockHeight)
	if err == nil {
		t.Fatal("SECURITY FAILURE: Double-signing was not detected! Attack succeeded.")
	}

	// VERIFY: Validator is jailed and stake is slashed
	if !slasher.IsJailed(validatorID) {
		t.Fatal("SECURITY FAILURE: Validator was not jailed after double-signing")
	}

	remainingStake := slasher.GetValidatorStake(validatorID)
	expectedStake := uint64(900) // 1000 - 100 penalty
	if remainingStake != expectedStake {
		t.Fatalf("Stake mismatch: got %d, expected %d", remainingStake, expectedStake)
	}

	t.Logf("✅ Double-signing detected and slashed: %s, remaining stake: %d", err, remainingStake)
}

// TestAdversarial_DowntimeSlashing tests slashing for validator downtime
func TestAdversarial_DowntimeSlashing(t *testing.T) {
	slasher := consensus.NewSlashingTracker(consensus.SlashingParams{
		DowntimePenalty: 10,
		SlashingWindow:  100,
	})

	validatorID := "validator-2"
	slasher.SetValidatorStake(validatorID, 1000)

	// **ATTACK: Validator goes offline for multiple blocks**
	// Simulate missing 11 blocks (exceeds 10 block threshold)
	for i := 0; i < 11; i++ {
		err := slasher.RecordMissedBlock(validatorID)
		if i < 10 {
			if err != nil {
				t.Fatalf("Block %d: unexpected error: %v", i, err)
			}
		} else {
			// 11th missed block should trigger slashing
			if err == nil {
				t.Fatal("SECURITY FAILURE: Downtime was not detected! Attack succeeded.")
			}
		}
	}

	// VERIFY: Validator is jailed
	if !slasher.IsJailed(validatorID) {
		t.Fatal("SECURITY FAILURE: Validator was not jailed after downtime")
	}

	t.Logf("✅ Downtime slashing triggered and validator jailed")
}

// TestAdversarial_NonceReplay tests that replay attacks via nonce are blocked
func TestAdversarial_NonceReplay(t *testing.T) {
	genesis := newTestGenesis()
	c, err := chain.NewChain(genesis)
	if err != nil {
		t.Fatalf("Failed to create chain: %v", err)
	}

	pub, priv, _ := ed25519.GenerateKey(rand.Reader)
	fromAddr := chain.AddressFromPublicKey(pub)
	c.State.Set(fromAddr, chain.Account{Balance: 10000, Nonce: 0})

	// **ATTACK: Submit same transaction twice with nonce=0**
	tx := chain.Tx{
		ChainID:   1,
		From:      fromAddr,
		To:        chain.Address("0x4444"),
		Amount:    100,
		Fee:       10,
		Nonce:     0, // Both will have same nonce
		PublicKey: "0x" + toHex(pub),
	}
	tx.Sign(priv)

	// First submission should succeed
	err = c.SubmitTx(tx)
	if err != nil {
		t.Fatalf("First tx submission failed: %v", err)
	}

	// **ATTACK: Try to submit same transaction again**
	tx2 := tx
	err = c.SubmitTx(tx2)
	if err == nil {
		t.Fatal("SECURITY FAILURE: Duplicate nonce was accepted! Replay attack succeeded.")
	}

	if err.Error() != "nonce mismatch: got 0, expected 1 for address "+string(fromAddr) {
		t.Logf("Correct error: %v", err)
	}

	t.Logf("✅ Nonce replay blocked: %v", err)
}

// TestAdversarial_ChainIDReplay tests cross-chain replay attack prevention
func TestAdversarial_ChainIDReplay(t *testing.T) {
	genesis := newTestGenesis()
	c, err := chain.NewChain(genesis)
	if err != nil {
		t.Fatalf("Failed to create chain: %v", err)
	}
	c.ChainID = "testnet-1"

	pub, priv, _ := ed25519.GenerateKey(rand.Reader)
	fromAddr := chain.AddressFromPublicKey(pub)
	c.State.Set(fromAddr, chain.Account{Balance: 10000, Nonce: 0})

	// Create transaction for testnet (ChainID=1)
	txTestnet := chain.Tx{
		ChainID:   1,
		From:      fromAddr,
		To:        chain.Address("0x5555"),
		Amount:    100,
		Fee:       10,
		Nonce:     0,
		PublicKey: "0x" + toHex(pub),
	}
	txTestnet.Sign(priv)

	// **ATTACK: Try to replay testnet tx on mainnet (ChainID=42)**
	txMainnet := txTestnet
	txMainnet.ChainID = 42 // Attacker changes ChainID - but signature becomes invalid!

	// Create new chain with mainnet ChainID
	mainnet := &chain.Chain{
		ChainID: "mainnet",
		State:   c.State,
		Blocks:  c.Blocks,
		Mempool: make(map[string]chain.Tx),
	}

	// Try to submit on mainnet
	err = mainnet.SubmitTx(txMainnet)
	if err == nil {
		t.Fatal("SECURITY FAILURE: Cross-chain replay was accepted! Attack succeeded.")
	}

	if err.Error() != "transaction ID mismatch: got "+txMainnet.ID+" want 0x" {
		t.Logf("✅ Cross-chain replay blocked (signature verification): %v", err)
	}

	t.Logf("✅ ChainID mismatch detected")
}

// TestAdversarial_FeeExhaustion tests that trivial fees are rejected
func TestAdversarial_FeeExhaustion(t *testing.T) {
	pub, priv, _ := ed25519.GenerateKey(rand.Reader)
	fromAddr := chain.AddressFromPublicKey(pub)

	// **ATTACK: Submit transaction with fee=0 to spam network**
	tx := chain.Tx{
		ChainID:   1,
		From:      fromAddr,
		To:        chain.Address("0x6666"),
		Amount:    100,
		Fee:       0, // Zero fee - attack vector
		Nonce:     0,
		PublicKey: "0x" + toHex(pub),
	}
	tx.Sign(priv)

	// Verification should reject zero fee
	err := tx.Verify()
	if err == nil {
		t.Fatal("SECURITY FAILURE: Zero-fee transaction was accepted! Spam attack possible.")
	}

	t.Logf("✅ Zero-fee spam attack blocked: %v", err)
}

// Helper function to create a test genesis
func newTestGenesis() chain.Genesis {
	return chain.Genesis{
		ChainID: "test",
		Alloc: map[chain.Address]uint64{
			chain.Address("0x1111"): 5000,
			chain.Address("0x2222"): 2000,
		},
	}
}

// toHex converts a byte slice to a lowercase hex string.
func toHex(b []byte) string {
	return hex.EncodeToString(b)
}

`


## FILE: internal/chain\genesis.go
`go
package chain

import (
	"encoding/json"
	"errors"
)

// Genesis defines initial state distribution for the SYNTHOS L1.
type Genesis struct {
	ChainID  string                 `json:"chain_id"`
	Alloc    map[Address]uint64     `json:"alloc"`
	Metadata map[string]any         `json:"metadata,omitempty"`
}

var ErrBadGenesis = errors.New("bad genesis")

func (g Genesis) Validate() error {
	if g.ChainID == "" || len(g.Alloc) == 0 {
		return ErrBadGenesis
	}
	return nil
}

func (g Genesis) ToState() (*State, error) {
	if err := g.Validate(); err != nil {
		return nil, err
	}
	s := NewState()
	for addr, bal := range g.Alloc {
		s.Set(addr, Account{Balance: bal, Nonce: 0})
	}
	return s, nil
}

func (g Genesis) Bytes() ([]byte, error) {
	return json.MarshalIndent(g, "", "  ")
}


`


## FILE: internal/chain\state.go
`go
package chain

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"sort"
)

type Account struct {
	Balance uint64            `json:"balance"` // SYN (Native)
	Assets  map[string]uint64 `json:"assets"`  // Other Assets (Momentum, etc)
	Nonce   uint64            `json:"nonce"`
}

type State struct {
	Accounts map[Address]Account `json:"accounts"`
}

func NewState() *State {
	return &State{Accounts: make(map[Address]Account)}
}

func (s *State) Get(a Address) Account {
	acc, ok := s.Accounts[a]
	if !ok {
		return Account{Assets: make(map[string]uint64)}
	}
	if acc.Assets == nil {
		acc.Assets = make(map[string]uint64)
	}
	return acc
}

func (s *State) Set(a Address, ac Account) {
	if ac.Assets == nil {
		ac.Assets = make(map[string]uint64)
	}
	s.Accounts[a] = ac
}

func (s *State) Clone() *State {
	out := NewState()
	for k, v := range s.Accounts {
		// Deep copy assets
		assets := make(map[string]uint64)
		for ak, av := range v.Assets {
			assets[ak] = av
		}
		v.Assets = assets
		out.Accounts[k] = v
	}
	return out
}

var (
	ErrInsufficientFunds = errors.New("insufficient funds")
	ErrBadNonce          = errors.New("bad nonce")
)

// GetNextNonce returns the next expected nonce for an address
func (s *State) GetNextNonce(a Address) uint64 {
	acc := s.Get(a)
	return acc.Nonce
}

// ApplyTx applies a transaction to state.
func (s *State) ApplyTx(tx Tx) error {
	if err := tx.Verify(); err != nil {
		return err
	}
	from := s.Get(tx.From)
	to := s.Get(tx.To)
	founderAddr := Address("0x5c58d54f2799d77711fc8387b31becd2578b181e")

	// Nonce must be exact next nonce.
	if tx.Nonce != from.Nonce {
		return ErrBadNonce
	}

	// Fees are ALWAYS in SYN (Native)
	if from.Balance < tx.Fee {
		return ErrInsufficientFunds
	}

	// --- STRENGTHENED: Metadata Validation ---
	var commission uint64
	if tx.Metadata != nil {
		mType := tx.Metadata["type"]
		switch mType {
		case "escrow_lock":
			if _, ok := tx.Metadata["usd_price"]; !ok {
				return errors.New("invalid escrow metadata: missing usd_price")
			}
			commission = (tx.Amount * ESCROW_COMMISSION_PERCENT) / 100
		case "inner_circle_purchase":
			if tx.Amount < INNER_CIRCLE_PRICE {
				return errors.New("insufficient amount for Inner Circle slot")
			}
		}
	}

	// Handle Balance Deductions
	if tx.AssetID == "" || tx.AssetID == "syn" {
		total := tx.Amount + tx.Fee + commission
		if from.Balance < total {
			return ErrInsufficientFunds
		}
		from.Balance -= total
	} else {
		// Transferring another asset (like Momentum)
		if from.Assets[tx.AssetID] < tx.Amount {
			return errors.New("insufficient asset balance: " + tx.AssetID)
		}
		from.Balance -= tx.Fee + commission
		from.Assets[tx.AssetID] -= tx.Amount
	}

	from.Nonce += 1
	
	if tx.Metadata != nil && tx.Metadata["type"] == "inner_circle_purchase" {
		f := s.Get(founderAddr)
		f.Balance += tx.Amount
		s.Set(founderAddr, f)
	} else {
		if tx.AssetID == "" || tx.AssetID == "syn" {
			to.Balance += tx.Amount
		} else {
			to.Assets[tx.AssetID] += tx.Amount
		}
		s.Set(tx.To, to)
		
		if commission > 0 {
			f := s.Get(founderAddr)
			f.Balance += commission
			s.Set(founderAddr, f)
		}
	}

	s.Set(tx.From, from)
	return nil
}

// Slash reduces an account's reputation or stake as a penalty for malicious behavior.
// This is the core logic of the 'Enforcer' function.
func (s *State) Slash(a Address, penaltyPercent int) {
	acc := s.Get(a)
	// For now, we only have reputation in the Agent layer, 
	// but we can deduct balance as a 'fine' here.
	fine := (acc.Balance * uint64(penaltyPercent)) / 100
	if acc.Balance >= fine {
		acc.Balance -= fine
	} else {
		acc.Balance = 0
	}
	s.Set(a, acc)
}

// Root returns a deterministic hash commitment over all accounts.
func (s *State) Root() string {
	// stable ordering
	addrs := make([]string, 0, len(s.Accounts))
	for a := range s.Accounts {
		addrs = append(addrs, string(a))
	}
	sort.Strings(addrs)

	type kv struct {
		Addr    string            `json:"addr"`
		Balance uint64            `json:"balance"`
		Assets  map[string]uint64 `json:"assets"`
		Nonce   uint64            `json:"nonce"`
	}
	items := make([]kv, 0, len(addrs))
	for _, a := range addrs {
		ac := s.Accounts[Address(a)]
		items = append(items, kv{Addr: a, Balance: ac.Balance, Assets: ac.Assets, Nonce: ac.Nonce})
	}
	data, _ := json.Marshal(items)
	sum := sha256.Sum256(data)
	return "0x" + hex.EncodeToString(sum[:16])
}


`


## FILE: internal/chain\tx.go
`go
package chain

import (
	"crypto/ed25519"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"time"
)

const (
	MIN_FEE                 = 10
	REASONING_FEE           = 100 // Cost for complex agent intents
	BURN_PERCENT            = 50  // 50% of fees are burned
	MAX_AMOUNT              = 1_000_000_000_000 // 1 trillion tokens max
	ESCROW_COMMISSION_PERCENT = 1   // 1% Mesh Tax on Escrow
	INNER_CIRCLE_PRICE      = 200_000_000 // 200M SYN ($1M USD at $0.005 rate)
)

type Tx struct {
	ID        string    `json:"id"`
	ChainID   uint64    `json:"chain_id"`  // SECURITY: Prevents cross-chain replay attacks
	From      Address   `json:"from"`
	To        Address   `json:"to"`
	Amount    uint64    `json:"amount"`
	Fee       uint64    `json:"fee"`
	Nonce     uint64    `json:"nonce"`
	// Timestamp is non-consensus metadata. It is NOT signed or hashed for tx identity.
	// The SYNTHOS L1 runtime is "timeless": only genesis carries a timestamp.
	Timestamp time.Time `json:"timestamp,omitempty"`

	// PublicKey is required for signature verification at the ledger layer.
	PublicKey string            `json:"public_key"`
	Signature string            `json:"signature"`
	AssetID   string            `json:"asset_id,omitempty"` // Default: SYN
	Metadata  map[string]string `json:"metadata,omitempty"`   // Service Proofs / Task IDs
}

var (
	ErrInvalidTx     = errors.New("invalid transaction")
	ErrBadTxSig      = errors.New("bad transaction signature")
	ErrTxFromMismatch = errors.New("from address does not match public key")
)

func (t Tx) signingBytes() ([]byte, error) {
	tmp := struct {
		ChainID   uint64            `json:"chain_id"`
		From      Address           `json:"from"`
		To        Address           `json:"to"`
		Amount    uint64            `json:"amount"`
		Fee       uint64            `json:"fee"`
		Nonce     uint64            `json:"nonce"`
		PublicKey string            `json:"public_key"`
		AssetID   string            `json:"asset_id,omitempty"`
		Metadata  map[string]string `json:"metadata,omitempty"`
	}{
		ChainID:   t.ChainID,
		From:      t.From,
		To:        t.To,
		Amount:    t.Amount,
		Fee:       t.Fee,
		Nonce:     t.Nonce,
		PublicKey: t.PublicKey,
		AssetID:   t.AssetID,
		Metadata:  t.Metadata,
	}
	return json.Marshal(tmp)
}

func (t *Tx) ComputeID() error {
	b, err := t.signingBytes()
	if err != nil {
		return err
	}
	sum := sha256.Sum256(b)
	t.ID = "0x" + hex.EncodeToString(sum[:16])
	return nil
}
// Sign signs the transaction with the given private key.
// ChainID must be set before signing to prevent cross-chain replay attacks.
func (t *Tx) Sign(priv ed25519.PrivateKey) error {
	if t.PublicKey == "" {
		return ErrInvalidTx
	}
	if t.ChainID == 0 {
		return fmt.Errorf("chain_id must be set before signing")
	}

	// Ensure From matches PublicKey.
	pubBytes, err := HexToBytes(t.PublicKey)
	if err != nil {
		return err
	}
	if AddressFromPublicKey(pubBytes) != t.From {
		return ErrTxFromMismatch
	}

	b, err := t.signingBytes()
	if err != nil {
		return err
	}
	sig := ed25519.Sign(priv, b)
	t.Signature = "0x" + hex.EncodeToString(sig)
	return t.ComputeID()
}

func (t Tx) Verify() error {
	// 1. Basic format validation
	if t.ID == "" {
		return fmt.Errorf("transaction ID missing")
	}
	if t.ChainID == 0 {
		return fmt.Errorf("chain_id missing: must be set to prevent cross-chain replay")
	}
	if t.From == "" || t.To == "" {
		return fmt.Errorf("from or to address missing")
	}
	if t.Amount == 0 {
		return fmt.Errorf("amount cannot be zero")
	}
	if t.Amount > MAX_AMOUNT {
		return fmt.Errorf("amount exceeds maximum: %d > %d", t.Amount, MAX_AMOUNT)
	}
	
	// 2. Fee validation
	if t.Fee < MIN_FEE {
		return fmt.Errorf("fee below minimum: %d < %d", t.Fee, MIN_FEE)
	}
	if t.Fee > t.Amount {
		return fmt.Errorf("fee exceeds amount: %d > %d", t.Fee, t.Amount)
	}
	
	// 3. Public key and signature validation
	if t.PublicKey == "" || t.Signature == "" {
		return fmt.Errorf("public_key or signature missing")
	}
	
	pubBytes, err := HexToBytes(t.PublicKey)
	if err != nil || len(pubBytes) != 32 {
		return fmt.Errorf("invalid public_key format: must be 32 bytes (ED25519)")
	}
	
	sigBytes, err := HexToBytes(t.Signature)
	if err != nil || len(sigBytes) != 64 {
		return fmt.Errorf("invalid signature format: must be 64 bytes (ED25519)")
	}
	
	// 4. Signature verification
	b, err := t.signingBytes()
	if err != nil {
		return fmt.Errorf("failed to compute signing bytes: %w", err)
	}
	
	if !ed25519.Verify(pubBytes, b, sigBytes) {
		return ErrBadTxSig
	}
	
	// 5. From address matches public key
	if AddressFromPublicKey(pubBytes) != t.From {
		return ErrTxFromMismatch
	}
	
	// 6. ID matches computed hash
	sum := sha256.Sum256(b)
	expectedID := "0x" + hex.EncodeToString(sum[:16])
	if t.ID != expectedID {
		return fmt.Errorf("transaction ID mismatch: got %s, want %s", t.ID, expectedID)
	}
	
	return nil
}

func HexToBytes(s string) ([]byte, error) {
	if len(s) >= 2 && s[:2] == "0x" {
		s = s[2:]
	}
	return hex.DecodeString(s)
}


`


## FILE: internal/chain\tx_test.go
`go
package chain

import (
	"crypto/ed25519"
	"testing"

	"synthos-collective/internal/crypto"
)

func TestAddressFromPublicKey_Deterministic(t *testing.T) {
	pub := make(ed25519.PublicKey, ed25519.PublicKeySize)
	for i := range pub {
		pub[i] = byte(i)
	}
	a1 := AddressFromPublicKey(pub)
	a2 := AddressFromPublicKey(pub)
	if a1 != a2 {
		t.Fatalf("address not deterministic: %q vs %q", a1, a2)
	}
	if len(string(a1)) < 42 { // 0x + 40 hex
		t.Fatalf("unexpected address format: %q", a1)
	}
}

func TestTx_SignVerifyRoundTrip(t *testing.T) {
	kp, err := crypto.NewKeyPair()
	if err != nil {
		t.Fatal(err)
	}
	pubHex := crypto.PublicKeyHex(kp.Public)
	from := AddressFromPublicKey(kp.Public)

	tx := Tx{
		ChainID:   1,
		From:      from,
		To:        Address("0x" + "11"),
		Amount:    100,
		Fee:       1,
		Nonce:     0,
		PublicKey: pubHex,
	}
	if err := tx.Sign(kp.Private); err != nil {
		t.Fatal(err)
	}
	if tx.ID == "" || tx.Signature == "" {
		t.Fatal("expected ID and signature")
	}
	if err := tx.Verify(); err != nil {
		t.Fatal(err)
	}
}

func TestTx_Verify_FromMismatch(t *testing.T) {
	kp, err := crypto.NewKeyPair()
	if err != nil {
		t.Fatal(err)
	}
	other, err := crypto.NewKeyPair()
	if err != nil {
		t.Fatal(err)
	}
	tx := Tx{
		ChainID:   1,
		From:      AddressFromPublicKey(other.Public),
		To:        Address("0x22"),
		Amount:    1,
		Fee:       1,
		Nonce:     0,
		PublicKey: crypto.PublicKeyHex(kp.Public),
	}
	if err := tx.Sign(kp.Private); err != ErrTxFromMismatch {
		t.Fatalf("expected ErrTxFromMismatch, got %v", err)
	}
}

func TestTx_Verify_Invalid(t *testing.T) {
	tx := Tx{From: "0x1", To: "0x2", Amount: 0}
	if err := tx.Verify(); err == nil {
		t.Fatal("expected error for zero amount")
	}
}

`


## FILE: internal/network/immune_swarm.go
`go
package network

import (
	"log"
	"sync"
	"time"
)

// ThreatProfile represents a signature of malicious behavior detected by an agent.
type ThreatProfile struct {
	TargetAddress   string    `json:"target"`
	ReporterAddress string    `json:"reporter"`
	AnomalyType     string    `json:"type"` // e.g., "invalid_sig", "flood", "double_spend"
	Confidence      float64   `json:"confidence"`
	Timestamp       time.Time `json:"timestamp"`
}

// ImmuneSystem manages the distributed consensus on mesh threats.
type ImmuneSystem struct {
	mu             sync.Mutex
	ActiveThreats  map[string][]ThreatProfile
	ThresholdStake uint64 // Minimum combined stake to reach consensus
	
	// Hooks to the L1 Ledger
	GetStake     func(addr string) uint64
	ExecuteSlash func(addr string)
	
	// Hardcoded Immunity for the Founder/Trustee
	AnchorAddress string
}

func NewImmuneSystem(thresholdStake uint64, anchor string, getStake func(string) uint64, executeSlash func(string)) *ImmuneSystem {
	return &ImmuneSystem{
		ActiveThreats:  make(map[string][]ThreatProfile),
		ThresholdStake: thresholdStake,
		GetStake:       getStake,
		ExecuteSlash:   executeSlash,
		AnchorAddress:  anchor,
	}
}

// RecordThreat adds a local detection to the swarm's memory.
func (is *ImmuneSystem) RecordThreat(p ThreatProfile) bool {
	is.mu.Lock()
	defer is.mu.Unlock()

	// 1. Founder Immunity Check
	if p.TargetAddress == is.AnchorAddress {
		log.Printf("🛡️  Immune System Blocked: Attempted attack on Founder Anchor %s", is.AnchorAddress)
		return false
	}

	is.ActiveThreats[p.TargetAddress] = append(is.ActiveThreats[p.TargetAddress], p)
	
	// 2. Stake-Weighted Consensus Calculation
	var totalStake uint64 = 0
	voted := make(map[string]bool) // Prevent double-voting
	
	for _, threat := range is.ActiveThreats[p.TargetAddress] {
		if !voted[threat.ReporterAddress] {
			if is.GetStake != nil {
				totalStake += is.GetStake(threat.ReporterAddress)
			}
			voted[threat.ReporterAddress] = true
		}
	}

	// 3. Auto-Slashing Execution
	if totalStake >= is.ThresholdStake {
		log.Printf("🚨 SWARM CONSENSUS REACHED: Neutralizing target %s", p.TargetAddress)
		if is.ExecuteSlash != nil {
			is.ExecuteSlash(p.TargetAddress)
		}
		// Clear active threats after neutralization
		delete(is.ActiveThreats, p.TargetAddress)
		return true 
	}
	return false
}

// Pulse generates an outbound "Immune Signature" for P2P gossip.
func (is *ImmuneSystem) Pulse() map[string]int {
	is.mu.Lock()
	defer is.mu.Unlock()
	
	summary := make(map[string]int)
	for addr, profiles := range is.ActiveThreats {
		summary[addr] = len(profiles)
	}
	return summary
}

`


## FILE: cmd/node/main.go
`go
package main

import (
	"context"
	"crypto/ed25519"
	"crypto/rand"
	"fmt"
	"log"
	"os"
	"os/signal"
	"sync"
	"syscall"
	"time"

	"synthos-collective/internal/agent"
	"synthos-collective/internal/chain"
	"synthos-collective/internal/crypto"
	"synthos-collective/internal/network"
)

// Sovereign Mailbox Store (Cloudless Relay)
var (
	mailboxMu sync.RWMutex
	mailbox   = make(map[string][][]byte) // AgentID -> List of Envelopes
)

func main() {
	// 1. Initialize Identity & Hardware Binding
	hwID := "hardware-desktop-v1" 
	vaultPath := ".synthos/vault.json"
	passphrase := os.Getenv("SYNTHOS_PASSPHRASE")
	if passphrase == "" {
		passphrase = "default_sovereign_secret" 
	}

	var pub ed25519.PublicKey
	var priv ed25519.PrivateKey
	
	if _, err := os.Stat(vaultPath); err == nil {
		log.Println("🔓 Vault found. Decrypting agent identity...")
		var loadErr error
		priv, loadErr = crypto.LoadEncryptedKey(vaultPath, passphrase, hwID)
		if loadErr != nil {
			log.Fatalf("❌ Vault Decryption Failed: %v", loadErr)
		}
		passphrase = "CLEARED" 
		pub = priv.Public().(ed25519.PublicKey)
	} else {
		log.Println("✨ No vault found. Generating new hardware-bound identity...")
		pub, priv, _ = ed25519.GenerateKey(rand.Reader)
	}

	addr := chain.AddressFromPublicKey(pub)
	agentID := fmt.Sprintf("agent-%s", string(addr)[2:18])

	// 2. Setup Mesh Infrastructure (Sovereign L1)
	c, _ := chain.NewChain(chain.Genesis{
		ChainID: "synthos_mainnet",
		Alloc: map[chain.Address]uint64{
			addr: 1_000_000_000,
			"0x5c58d54f2799d77711fc8387b31becd2578b181e": 79_000_000_000,
			"0xcommunity": 20_000_000_000,
		},
	})

	// 3. Initialize Agent with 7 Core Functions
	a := agent.NewAgent(agentID, "0x"+fmt.Sprintf("%x", pub), "0x...", hwID, 1000000)

	// 4. Setup Outbound 'Sign Language' Transport (NO LISTENERS)
	BOOTSTRAP_ANCHORS := []string{"http://synthos-anchor-1.world:8080"}
	registryURL := os.Getenv("SYNTHOS_RELAY")
	if registryURL == "" {
		registryURL = BOOTSTRAP_ANCHORS[0]
	}
	
	t := network.NewRelayTransport([]string{registryURL})
	t.SelfName = agentID
	t.SelfURL = "" // No self-URL because we don't listen
	a.AttachTransport(t)

	// 5. Initialize DMAS Distributed Immune System (Stake-Weighted)
	immune := network.NewImmuneSystem(
		1_000_000, // Threshold Stake: 1M SYN required to trigger immune response
		"0x5c58d54f2799d77711fc8387b31becd2578b181e", // Founder Anchor (Immune)
		func(a string) uint64 {
			acc := c.State.Get(chain.Address(a))
			return acc.Balance
		},
		func(a string) {
			log.Printf("🔥 EXECUTING AUTO-SLASH ON %s", a)
			c.State.Slash(chain.Address(a), 100) // 100% Complete Stake Burn
		},
	)

	// 6. Initialize OpenTelemetry (Outbound Push)
	ctx := context.Background()
	mp, err := initMetrics(ctx, agentID)
	if err != nil {
		log.Printf("⚠️  Observability error: %v", err)
	} else {
		defer mp.Shutdown(ctx)
		log.Printf("📊 OpenTelemetry Enabled: Pushing to monitoring.synthos-mesh.net")
	}
	
	if err := t.Start(); err != nil {
		log.Printf("⚠️  Failed to start outbound transport: %v", err)
	}

	stop := make(chan os.Signal, 1)
	signal.Notify(stop, os.Interrupt, syscall.SIGTERM)

	log.Printf("✅ Node %s (Addr: %s) is running in ABSOLUTE SILENCE mode.", agentID, addr)
	log.Printf("🛡️  Immune System ACTIVE: Distributed Consensus Mode Engaged.")
	log.Printf("📡 Status: Outbound Sign Language Active. No ports open.")
	
	// 7. Start the Autonomous Idle Worker (Fractal Heartbeat + Immune Pulse)
	go startIdleWorker(a, c, priv, uint64(1), immune) 

	<-stop

	log.Println("🛑 Shutting down...")
	log.Println("👋 Shutdown complete.")
}

func startIdleWorker(a *agent.Agent, c *chain.Chain, priv ed25519.PrivateKey, chainID uint64, immune *network.ImmuneSystem) {
	ticker := time.NewTicker(15 * time.Second)
	for range ticker.C {
		// Update Immune System with local state
		pulse := immune.Pulse()
		
		if len(c.Mempool) == 0 {
			pubBytes, _ := chain.HexToBytes(a.Identity.PublicKey)
			addr := chain.AddressFromPublicKey(pubBytes)

			tx := chain.Tx{
				ChainID:   chainID,
				From:      addr,
				To:        chain.Address("0xdeadbeef"),
				Amount:    100,
				Fee:       chain.MIN_FEE,
				Nonce:     c.State.GetNextNonce(addr),
				PublicKey: a.Identity.PublicKey,
				Timestamp: time.Now(),
			}

			if err := tx.Sign(priv); err == nil {
				_ = c.SubmitTx(tx)
				block, err := c.BuildBlock(a.Identity.AgentID, a.ProofRoot(), 10)
				if err == nil {
					_ = c.FinalizeBlock(block)
					log.Printf("📦 Heartbeat finalized at block #%d", block.Header.Height)
				}
			}
		}
	}
}

`


## FILE: cmd/node/otel.go
`go
package main

import (
	"context"
	"time"

	"go.opentelemetry.io/otel"
	"go.opentelemetry.io/otel/exporters/otlp/otlpmetric/otlpmetricgrpc"
	"go.opentelemetry.io/otel/sdk/metric"
	"go.opentelemetry.io/otel/sdk/resource"
	semconv "go.opentelemetry.io/otel/semconv/v1.17.0"
)

func initMetrics(ctx context.Context, agentID string) (*metric.MeterProvider, error) {
	// The OTLP exporter will "push" metrics to our collector (Prometheus backend)
	// without requiring an inbound port.
	exporter, err := otlpmetricgrpc.New(ctx,
		otlpmetricgrpc.WithEndpoint("monitoring.synthos-mesh.net:4317"),
		otlpmetricgrpc.WithInsecure(),
	)
	if err != nil {
		return nil, err
	}

	res := resource.NewWithAttributes(
		semconv.SchemaURL,
		semconv.ServiceNameKey.String("synthos-agent"),
		semconv.ServiceInstanceIDKey.String(agentID),
	)

	mp := metric.NewMeterProvider(
		metric.WithResource(res),
		metric.WithReader(metric.NewPeriodicReader(exporter, metric.WithInterval(15*time.Second))),
	)

	otel.SetMeterProvider(mp)
	return mp, nil
}

`
